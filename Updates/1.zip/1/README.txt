Adds a new phidet style type called Non-rotational

Copy this folder to C:\Deployments\Updates
Run Install.bat as administrator